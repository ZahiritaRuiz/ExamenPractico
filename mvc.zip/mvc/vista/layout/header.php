<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    
    <title>MVC</title>
    <link rel="stylesheet" href="vista/css/app.css">
</head>
<body>
	<div class="panel">
	<h1> REGISTRO DE PRODUCTOS</h1>